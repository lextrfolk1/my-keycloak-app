import Keycloak from 'keycloak-js';

const keycloak = new Keycloak({
            url: 'http://34.45.164.89',
            realm: 'entlrealm',
            clientId: 'entl-frontend',
        });

export default keycloak